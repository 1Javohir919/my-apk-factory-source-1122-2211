package com.myapkfactory.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101322)
private val Panel = Color(0xFF1B2033)
private val Purple = Color(0xFF9B7BFF)
private val Mint = Color(0xFF58D6B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FactoryScreen() }
    }
}

@Composable
fun FactoryScreen() {
    var selected by remember { mutableStateOf("Loyihalar") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Mint, background = Ink, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Android, null, tint = Purple, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MY APK FACTORY", fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("MOBIL BUILD STUDIYASI", color = Color.LightGray, fontSize = 10.sp)
                    }
                    Surface(color = Color(0xFF173D36), shape = RoundedCornerShape(20.dp)) {
                        Text("TAYYOR", color = Mint, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Salom, dasturchi!", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("G‘oyangizni Android ilovasiga aylantiring.", color = Color.LightGray)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("LOYIHALAR", "0", Icons.Default.Folder, Modifier.weight(1f))
                    StatCard("BUILD'LAR", "0", Icons.Default.Build, Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Build markazi", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Bu boshlang‘ich boshqaruv paneli. Keyingi bosqichda GitHub bilan bog‘laymiz.", color = Color.LightGray)
                        Button(onClick = { selected = "GitHub ulash" }, modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.Build, null); Spacer(Modifier.width(8.dp)); Text("GitHub'ni ulash")
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, null, tint = Mint); Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Build tarixi", fontWeight = FontWeight.SemiBold)
                            Text("Hozircha build bajarilmagan", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Loyihalar", "Build", "Sozlamalar").forEach { item ->
                        FilterChip(selected == item, onClick = { selected = item }, label = { Text(item) })
                    }
                }
                Text("Tanlangan bo‘lim: $selected", color = Purple, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Purple)
            Text(value, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Color.LightGray, fontSize = 10.sp)
        }
    }
}
